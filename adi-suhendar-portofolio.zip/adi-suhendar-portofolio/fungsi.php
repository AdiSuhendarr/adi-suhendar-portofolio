<?php
function potong($artikel, $wordLimit, $id){
    $word = explode(" ", $artikel);  
    $result = implode(" ",array_slice($word,0,$wordLimit));

    if(count($word) > $wordLimit){
        $result .= '<br><a href="blog-single.php?id='.$id.'">Read more</a>';
    }
    return $result;

}
?>