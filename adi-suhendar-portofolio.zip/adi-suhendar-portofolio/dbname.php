<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "portofolio_uts_web_blended";

$conn = mysqli_connect($serverName, $userName, $password, $dbName);
if(!$conn){
    die("Koneksi Gagal");
}

?>