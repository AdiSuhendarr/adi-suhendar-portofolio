-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2023 at 04:01 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portofolio_uts_web_blended`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(5) NOT NULL COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabel About';

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `judul`, `subjudul`, `tgl`, `gbr`, `isi`) VALUES
(1, 'About Me', '', '2023-11-04 20:51:15', 'assets/images/ab-img.png', '<p class=\"wow fadeInUp\"> Adi Suhendar</p>\r\n<p class=\"wow fadeInUp\"> SDN Kancanamulya - 2012</p>\r\n<p class=\"wow fadeInUp\"> SMPN 1 Gekbrong - 2015</p>\r\n<p class=\"wow fadeInUp\"> SMK Bela Nusantara - 2018</p>\r\n<p class=\"wow fadeInUp\"> Universitas Pembangunan Jaya</p>');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(5) NOT NULL COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabel Blog';

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `judul`, `subjudul`, `tgl`, `gbr`, `isi`) VALUES
(1, 'Keamanan Siber', '', '2023-11-04 21:06:04', 'assets/images/b-4.jpg', 'Keamanan siber adalah praktik melindungi komputer, jaringan, aplikasi perangkat lunak, sistem kritis, dan data dari potensi ancaman digital. Organisasi memiliki tanggung jawab untuk mengamankan data guna menjaga kepercayaan pelanggan dan memenuhi kepatuhan terhadap peraturan. Organisasi menggunakan langkah-langkah dan alat keamanan siber untuk melindungi data sensitif dari akses yang tidak sah, serta mencegah gangguan dalam operasi bisnis karena aktivitas jaringan yang tidak diinginkan. Organisasi menerapkan keamanan siber dengan merampingkan pertahanan digital di antara personel, proses, dan teknologi.'),
(2, 'Network Engineer', '', '2023-11-04 21:08:22', 'assets/images/b-5.jpg', 'Network Engineer (NE) adalah orang yang bertugas untuk membangun sebuah jaringan di suatu organisasi atau perusahaan. Selain itu, mereka juga bertugas mendesain, implementasi, dan melakukan pemeliharaan agar jaringan tidak mengalami masalah.');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(5) NOT NULL COMMENT 'Id',
  `phone` varchar(50) NOT NULL COMMENT 'Phone',
  `email` varchar(50) NOT NULL COMMENT 'Email',
  `alamat` text NOT NULL COMMENT 'Alamat',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabel Contact';

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `phone`, `email`, `alamat`, `tgl`) VALUES
(1, '082319694243', 'adisuhendar65@email.com', 'Jakarta, Indonesia', '2023-11-04 21:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(5) NOT NULL COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabel Home';

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `judul`, `subjudul`, `tgl`, `gbr`, `isi`) VALUES
(1, 'Adi Suhendar', 'Indomaret Group', '2023-11-04 20:28:04', 'assets/images/foto-home.jpg', '<ul>\r\n <li class=\"wow fadeInUp\" data-wow-duration=\"0.8s\" data-wow-delay=\"0.4s\"><i class=\"fa fa-envelope\"></i><a href=\"mailto:adisuhendar65@email.com\">adisuhendar65@email.com</a></li>\r\n <li class=\"wow fadeInUp\" data-wow-duration=\"0.8s\" data-wow-delay=\"0.5s\"><i class=\"fa fa-phone\"></i><a href=\"callto:+6282319694243\">+6282319694243</a></li>\r\n <li class=\"wow fadeInUp\" data-wow-duration=\"0.8s\" data-wow-delay=\"0.6s\"><i class=\"fa fa-map-marker\"></i><address>Jakarta, Indonesia</address></li>\r\n</ul>');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(5) NOT NULL COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabel Portofolio';

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `judul`, `subjudul`, `tgl`, `gbr`, `isi`) VALUES
(1, 'Skills', '', '2023-11-04 20:57:33', '', '<div class=\"row section-separator\">\r\n                    <div class=\"section-title text-center col-sm-12\">\r\n                        <!--<h2>Skills</h2>-->\r\n                    </div>\r\n                    <div class=\"col-sm-12 col-md-12\">\r\n                        <div class=\"mh-skills-inner\">\r\n                            <div class=\"mh-professional-skill wow fadeInUp\" data-wow-duration=\"0.8s\" data-wow-delay=\"0.3s\">\r\n                                <h3>Technical Skills</h3>\r\n                                <div class=\"each-skills\">\r\n                                    <div class=\"candidatos\">\r\n                                        <div class=\"parcial\">\r\n                                            <div class=\"info\">\r\n                                                <div class=\"nome\">Networking</div>\r\n                                                <div class=\"percentagem-num\">86%</div>\r\n                                            </div>\r\n                                            <div class=\"progressBar\">\r\n                                                <div class=\"percentagem\" style=\"width: 86%;\"></div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"candidatos\">\r\n                                        <div class=\"parcial\">\r\n                                            <div class=\"info\">\r\n                                                <div class=\"nome\">Java</div>\r\n                                                <div class=\"percentagem-num\">46%</div>\r\n                                            </div>\r\n                                            <div class=\"progressBar\">\r\n                                                <div class=\"percentagem\" style=\"width: 46%;\"></div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"candidatos\">\r\n                                        <div class=\"parcial\">\r\n                                            <div class=\"info\">\r\n                                                <div class=\"nome\">Python</div>\r\n                                                <div class=\"percentagem-num\">38%</div>\r\n                                            </div>\r\n                                            <div class=\"progressBar\">\r\n                                                <div class=\"percentagem\" style=\"width: 38%;\"></div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"candidatos\">\r\n                                        <div class=\"parcial\">\r\n                                            <div class=\"info\">\r\n                                                <div class=\"nome\">PHP</div>\r\n                                                <div class=\"percentagem-num\">17%</div>\r\n                                            </div>\r\n                                            <div class=\"progressBar\">\r\n                                                <div class=\"percentagem\" style=\"width: 17%;\"></div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>                                    \r\n                                    <div class=\"candidatos\">\r\n                                        <div class=\"parcial\">\r\n                                            <div class=\"info\">\r\n                                                <div class=\"nome\">Data Science</div>\r\n                                                <div class=\"percentagem-num\">17%</div>\r\n                                            </div>\r\n                                            <div class=\"progressBar\">\r\n                                                <div class=\"percentagem\" style=\"width: 17%;\"></div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    \r\n                </div>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id', AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
