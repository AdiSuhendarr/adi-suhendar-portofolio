<?php
header('Access-Control-Allow_Origin:*');
header('Content-Type: application/json');

include "dbname.php";
include "fungsi.php";

$id = (isset($_GET["id"])? $_GET["id"] : 0);

if ($_GET["tipe"]=="home") {
$sql = 'SELECT * FROM home';
} else if ($_GET["tipe"]=="about")  {
$sql = 'SELECT * FROM about';
} else if ($_GET["tipe"]=="skills")  {
$sql = 'SELECT * FROM skills';
} else if ($_GET["tipe"]=="blog")  {
$sql = 'SELECT * FROM blog where id='.$id;
} else if ($_GET["tipe"]=="contact")  {
$sql = 'SELECT * FROM contact';
}


$result = mysqli_query($conn,$sql);

$data=array();

$jmlData = mysqli_num_rows($result);

if ($jmlData >0){
    $row = mysqli_fetch_assoc($result);
    $data = $row;
}else{

    $data['error'] = 'Data Tidak ditemukan atau invalid id';
}

echo json_encode($data);

?>